<?php
/**
 * Settings AJAX handler.
 *
 * Handles all settings and configuration-related AJAX operations including
 * URL management, website/group creation, and initial setup processes.
 *
 * @link       https://www.webchangedetector.com
 * @since      4.0.0
 * @package    WebChangeDetector
 * @subpackage WebChangeDetector/admin/ajax
 */

namespace WebChangeDetector;

/**
 * Settings AJAX handler.
 *
 * Handles all settings and configuration-related AJAX operations.
 *
 * @since      4.0.0
 * @package    WebChangeDetector
 * @subpackage WebChangeDetector/admin/ajax
 * @author     Mike Miler <mike@webchangedetector.com>
 */
class WebChangeDetector_Settings_Ajax_Handler extends WebChangeDetector_Ajax_Handler_Base {

	/**
	 * The settings handler instance.
	 *
	 * @since    4.0.0
	 * @access   private
	 * @var      WebChangeDetector_Admin_Settings    $settings_handler    The settings handler instance.
	 */
	private $settings_handler;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    4.0.0
	 * @param    WebChangeDetector_Admin          $admin            The main admin class instance.
	 * @param    WebChangeDetector_Admin_Settings $settings_handler The settings handler instance.
	 */
	public function __construct( $admin, $settings_handler ) {
		parent::__construct( $admin );

		$this->settings_handler = $settings_handler;
	}

	/**
	 * Register AJAX hooks for settings operations.
	 *
	 * Registers all WordPress AJAX hooks for settings-related operations.
	 *
	 * @since    4.0.0
	 */
	public function register_hooks() {
		add_action( 'wp_ajax_post_url', array( $this, 'ajax_post_url' ) );
		add_action( 'wp_ajax_wcd_disable_wizard', array( $this, 'ajax_disable_wizard' ) );
		add_action( 'wp_ajax_create_website_and_groups_ajax', array( $this, 'ajax_create_website_and_groups' ) );
		add_action( 'wp_ajax_wcd_get_initial_setup', array( $this, 'ajax_get_initial_setup' ) );
		add_action( 'wp_ajax_wcd_save_initial_setup', array( $this, 'ajax_save_initial_setup' ) );
		add_action( 'wp_ajax_wcd_update_sync_types_with_local_labels', array( $this, 'ajax_update_sync_types_with_local_labels' ) );
		add_action( 'wp_ajax_wcd_complete_initial_setup', array( $this, 'ajax_complete_initial_setup' ) );
		add_action( 'wp_ajax_wcd_export_logs', array( $this, 'ajax_export_logs' ) );
		add_action( 'wp_ajax_sync_urls', array( $this, 'ajax_sync_urls' ) );
	}

	/**
	 * Handle post URL AJAX request.
	 *
	 * Processes URL settings and saves them to the database.
	 * Delegates to the main admin class for backwards compatibility.
	 *
	 * @since    4.0.0
	 */
	public function ajax_post_url() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			// Delegate to main admin class for now (will be refactored later).
			if ( $this->admin && method_exists( $this->admin, 'post_urls' ) ) {
				// Capture any output from the post_urls method.
				ob_start();
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce already verified above.
				$this->admin->post_urls( $_POST );
				ob_get_clean();

				$this->send_success_response(
					null,
					__( 'Settings saved successfully.', 'webchangedetector' )
				);
			} else {
				$this->send_error_response(
					__( 'Method not available.', 'webchangedetector' ),
					'post_urls method missing'
				);
			}
		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while saving settings.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle disable wizard AJAX request.
	 *
	 * Disables the setup wizard and updates the user preference.
	 *
	 * @since    4.0.0
	 */
	public function ajax_disable_wizard() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			$result = update_option( 'wcd_wizard_disabled', true );

			if ( $result ) {
				$this->send_success_response(
					array( 'wizard_disabled' => true ),
					__( 'Wizard disabled successfully.', 'webchangedetector' )
				);
			} else {
				$this->send_error_response(
					__( 'Failed to disable wizard.', 'webchangedetector' ),
					'Option update failed'
				);
			}
		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while disabling wizard.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle create website and groups AJAX request.
	 *
	 * Creates a website and associated groups via the API.
	 *
	 * @since    4.0.0
	 */
	public function ajax_create_website_and_groups() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			$result = $this->admin->create_website_and_groups();

			if ( isset( $result['error'] ) ) {
				$this->send_error_response(
					$result['error'],
					'Website creation failed'
				);
			} else {
				$this->send_success_response( $result );
			}
		} catch ( \Exception $e ) {
			$this->admin->log_error( 'Exception during website creation: ' . $e->getMessage() );
			$this->send_error_response(
				$e->getMessage(),
				'Exception during website creation'
			);
		}
	}

	/**
	 * Handle get initial setup AJAX request.
	 *
	 * Retrieves initial setup data for the setup wizard.
	 *
	 * @since    4.0.0
	 */
	public function ajax_get_initial_setup() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			$setup_data = array(
				'website_details'      => $this->admin->website_details,
				'available_sync_types' => $this->settings_handler->get_available_sync_types(),
				'current_sync_types'   => get_option( 'wcd_sync_url_types', array() ),
			);

			$this->send_success_response( $setup_data );

		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'Failed to get initial setup data.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle save initial setup AJAX request.
	 *
	 * Saves initial setup configuration data.
	 *
	 * @since    4.0.0
	 */
	public function ajax_save_initial_setup() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			$post_data = $this->validate_post_data( array( 'sync_types' ) );

			if ( false === $post_data ) {
				$this->send_error_response(
					__( 'Missing sync types data.', 'webchangedetector' ),
					'Missing sync_types'
				);
				return;
			}

			$sync_types = $post_data['sync_types'];

			// Validate sync types.
			$available_types = $this->settings_handler->get_available_sync_types();
			$valid_types     = array();

			foreach ( $sync_types as $type ) {
				if ( isset( $available_types[ $type ] ) ) {
					$valid_types[] = $type;
				}
			}

			update_option( 'wcd_sync_url_types', $valid_types );

			$this->send_success_response(
				array( 'sync_types' => $valid_types ),
				__( 'Initial setup saved successfully.', 'webchangedetector' )
			);

		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while saving initial setup.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle update sync types with local labels AJAX request.
	 *
	 * Updates sync types configuration with localized labels.
	 *
	 * @since    4.0.0
	 */
	public function ajax_update_sync_types_with_local_labels() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			// Get current sync types or use default ones if not set.
			$current_sync_types = get_option( 'wcd_sync_url_types', array() );

			// If no sync types are currently set, use default ones.
			if ( empty( $current_sync_types ) ) {
				$settings_handler   = new \WebChangeDetector\WebChangeDetector_Admin_Settings( $this->admin );
				$website_details    = $settings_handler->get_website_details();
				$current_sync_types = $website_details['sync_url_types'];
			}

			// Save the sync types.
			update_option( 'wcd_sync_url_types', $current_sync_types );

			$this->send_success_response(
				array( 'sync_url_types' => $current_sync_types ),
				__( 'Sync types updated successfully.', 'webchangedetector' )
			);

		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while updating sync types.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle complete initial setup AJAX request.
	 *
	 * Completes the initial setup process and marks it as finished.
	 *
	 * @since    4.0.0
	 */
	public function ajax_complete_initial_setup() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			// Clear the initial setup needed flag.
			delete_option( WCD_WP_OPTION_KEY_INITIAL_SETUP_NEEDED );

			// Mark setup as completed.
			update_option( 'wcd_initial_setup_completed', true );

			// Enable wizard for first-time users.
			update_option( 'wcd_wizard', 'true' );

			$this->send_success_response(
				array(
					'setup_completed' => true,
					'wizard_enabled'  => true,
				),
				__( 'Initial setup completed successfully.', 'webchangedetector' )
			);

		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while completing initial setup.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}


	/**
	 * Handle sync URLs AJAX request.
	 *
	 * Synchronizes URLs with the WebChangeDetector API using the existing sync_posts method.
	 * Returns the formatted last sync date as plain text (not JSON) to match JavaScript expectations.
	 *
	 * @since    4.0.0
	 */
	public function ajax_sync_urls() {
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce already verified in security_check.
			$force = isset( $_POST['force'] ) ? intval( $_POST['force'] ) : 0;

			// Get the admin WordPress instance which has the sync_posts method.
			$admin_wordpress = new \WebChangeDetector\WebChangeDetector_Admin_WordPress(
				'webchangedetector',
				WEBCHANGEDETECTOR_VERSION,
				$this->admin
			);

			// Call the existing sync_posts method with force parameter.
			$result = $admin_wordpress->sync_posts( (bool) $force );

			if ( $result ) {
				// The sync_posts method returns the formatted date on success or when skipped.
				if ( is_string( $result ) ) {
					// Return the formatted date string.
					echo esc_html( $result );
				} else {
					// If true is returned, get the current formatted date.
					echo esc_html( date_i18n( 'd/m/Y H:i', get_option( 'wcd_last_urls_sync' ) ) );
				}
			} else {
				// Sync failed.
				echo esc_html__( 'Sync failed', 'webchangedetector' );
			}

			wp_die();

		} catch ( \Exception $e ) {
			// Log error if possible.
			if ( $this->admin && method_exists( $this->admin, 'log_error' ) ) {
				$this->admin->log_error( 'URL sync failed: ' . $e->getMessage() );
			}

			// Return error message as plain text.
			echo esc_html__( 'Sync failed', 'webchangedetector' );
			wp_die();
		}
	}

	/**
	 * Handle export logs AJAX request.
	 *
	 * Exports logs as CSV data and returns it for download.
	 *
	 * @since    4.0.0
	 */
	public function ajax_export_logs() {
		// Use WebChangeDetector nonce verification for consistency with the rest of the system.
		if ( ! $this->security_check() ) {
			return;
		}

		try {
			// Get filters from POST data.
			$filters       = array();
			$filter_fields = array( 'level', 'context', 'search', 'date_from', 'date_to' );
			foreach ( $filter_fields as $field ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce already verified in wcd_security_check.
				if ( ! empty( $_POST[ $field ] ) ) {
					// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce already verified in wcd_security_check.
					$filters[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
				}
			}

			// Initialize database logger.
			$logger = new \WebChangeDetector\WebChangeDetector_Database_Logger();

			// Generate CSV.
			$csv_content = $logger->export_to_csv( $filters );

			// Debug logging.
			if ( $this->admin && method_exists( $this->admin, 'log_error' ) ) {
				$this->admin->log_error( 'CSV Export: Generated ' . strlen( $csv_content ) . ' bytes of CSV data', 'ajax_export_logs', 'debug' );
			}

			// Generate filename.
			$filename = 'wcd-logs-' . gmdate( 'Y-m-d-H-i-s' ) . '.csv';

			// Check if CSV content is valid.
			if ( empty( $csv_content ) ) {
				$this->send_error_response(
					__( 'No logs found to export.', 'webchangedetector' ),
					'Empty CSV content'
				);
				return;
			}

			$this->send_success_response(
				array(
					// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Used for safe data transport to JavaScript.
					'csv_content' => base64_encode( $csv_content ),
					'filename'    => $filename,
					'debug_info'  => array(
						'original_size' => strlen( $csv_content ),
						// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Used for safe data transport to JavaScript.
						'encoded_size'  => strlen( base64_encode( $csv_content ) ),
					),
				),
				__( 'Logs exported successfully.', 'webchangedetector' )
			);

		} catch ( \Exception $e ) {
			$this->send_error_response(
				__( 'An error occurred while exporting logs.', 'webchangedetector' ),
				'Exception: ' . $e->getMessage()
			);
		}
	}
}
