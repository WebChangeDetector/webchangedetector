<?php
/**
 * Title: WebChange Detector Admin
 * Description: WebChange Detector Admin
 * Version: 1.0
 *
 * @package    WebChangeDetector
 *
 * Silence is golden.
 */
