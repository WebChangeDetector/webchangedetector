<?php
/**
 * Title: WebChange Detector Index
 * Description: WebChange Detector Index
 * Version: 1.0
 *
 * @package    WebChangeDetector
 *
 * Silence is golden.
 */
