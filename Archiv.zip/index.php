<?php
/**
 * Silence is golden.
 *
 * @package    WebChangeDetector
 * */
